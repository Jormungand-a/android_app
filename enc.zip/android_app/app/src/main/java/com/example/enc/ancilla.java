package com.example.enc;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GestureDetectorCompat;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;

import android.widget.EditText;

import android.widget.Toast;

import java.util.Observable;

public class ancilla extends AppCompatActivity {
    public static final String PREFS_NAME = "MyPrefsFile";


    int current_chaos = 7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page);

    }


    public void dialog(View v){
        LayoutInflater factory = LayoutInflater.from(this);
        final View textEntryView = factory.inflate(R.layout.dialog, null);
        final EditText editTextnumber = (EditText) textEntryView.findViewById(R.id.editTextnumber);
        final EditText editTextkey = (EditText)textEntryView.findViewById(R.id.editTextkey);
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        final String cur_key = settings.getString("my_key","hello");
        AlertDialog.Builder ad1 = new AlertDialog.Builder(this);
        ad1.setTitle("enquiry:");
        ad1.setIcon(android.R.drawable.ic_dialog_info);
        ad1.setView(textEntryView);
        ad1.setPositiveButton("done", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int i) {
                SharedPreferences settings = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = settings.edit();
                String num =editTextnumber.getText().toString();
                String cc_key = editTextkey.getText().toString();
                if (cc_key.contentEquals(cur_key)){
                    int numm= settings.getInt(num,-3);
                    Toast.makeText(ancilla.this,String.valueOf(numm),Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ancilla.this,"password is wrong",Toast.LENGTH_SHORT).show();
                }
            }
        });
        ad1.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int i) {

            }
        });
        //register
        final EditText inputServer = new EditText(this);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("register").setIcon(android.R.drawable.ic_dialog_info).setView(inputServer)
                .setNegativeButton("Cancel", null);
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                String my_ley = inputServer.getText().toString();
                SharedPreferences settings = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("my_key",my_ley);
                editor.commit();
            }
        });


        if(cur_key=="hello"){
            builder.show();
        } else {
            ad1.show();
        }
    }


}
