package com.example.multi;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GestureDetectorCompat;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.icu.text.SimpleDateFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;
public class MainActivity extends AppCompatActivity {
    public static final String PREFS_NAME = "MyPrefsFile";
    private GestureDetectorCompat myfinger;
    HashMap<Character ,Integer> mapcti = new HashMap <Character, Integer> ();
    HashMap<Integer ,Character> mapitc = new HashMap <Integer , Character> ();
    int num[] = new int[64];
    char cha[] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o'
            ,'p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F',
            'G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V'
            ,'W','X','Y','Z','0','1','2','3','4','5','6','7','8','9','.',' '};
    private  static final int gallery_request_code = 7;
    private  static final int gallery_request_key = 13;
    ImageView imv_pho;
    Button but_pho;
    int global_bar = 0;
    SeekBar skb;
    ImageView imv_key;
    Button but_key;
    double coffecient = 4.0;
    int pagepointer = 1;
    Bitmap photo = null;
    Bitmap mask = null;
    int current_chaos = 7;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = settings.edit();
        current_chaos =  settings.getInt("0",-7);
        if (current_chaos == -7){
           current_chaos = 0;
           editor.putInt("0",0);
           editor.commit();
        }

        setContentView(R.layout.activity_main);
        imv_pho=findViewById(R.id.photo);
        but_pho=findViewById(R.id.photob);
        imv_key = findViewById(R.id.mask);
        but_key = findViewById(R.id.maskb);
        skb = findViewById(R.id.sb);
        final TextView tvn = findViewById(R.id.barn);
        for( int i=0;i<64;i++){
            num[i]=i;
        }
        for(int i=0;i<64;i++){
            mapitc.put(i,cha[i]);
            mapcti.put(cha[i],i);
        }

        skb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                String g = String.valueOf(progress);
                global_bar = progress;
                tvn.setText(g);
                CheckBox ck1x = findViewById(R.id.ck1);
                CheckBox ck2x = findViewById(R.id.ck2);
                CheckBox ck3x = findViewById(R.id.ck0);
                if (progress>0) {
                    ck3x.setChecked(true);
                    ck2x.setChecked(false);
                    ck1x.setChecked(false);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                return;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                return;
            }

        });

        myfinger = new GestureDetectorCompat(this, new fingerlistener());
    }

    private class fingerlistener extends GestureDetector.SimpleOnGestureListener{
        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            float d2 = e2.getX(); float d1 = e1.getX();
            if (Math.abs(d1-d2)>200){
                if (d2>d1){
                    if (pagepointer==1){
                        Toast.makeText(MainActivity.this,"to the mask page",Toast.LENGTH_SHORT).show();
                        pagepointer=0;
                        setContentView(R.layout.page);
                    }
                    if (pagepointer==0){
                        Toast.makeText(MainActivity.this,"no page on left",Toast.LENGTH_SHORT).show();
                    }
                }

                if (d1>d2){
                    if (pagepointer==0){
                        Toast.makeText(MainActivity.this,"to the main page",Toast.LENGTH_SHORT).show();
                        pagepointer=1;
                        setContentView(R.layout.activity_main);
                        final SeekBar skb = findViewById(R.id.sb);
                        skb.setProgress(global_bar);
                        final TextView tvn = findViewById(R.id.barn);
                        tvn.setText(String.valueOf(global_bar));
                        skb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                            @Override
                            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                                String g = String.valueOf(progress);
                                global_bar = progress;
                                CheckBox ck1x = findViewById(R.id.ck1);
                                CheckBox ck2x = findViewById(R.id.ck2);
                                CheckBox ck3x = findViewById(R.id.ck0);
                                tvn.setText(g);
                                if (progress>0) {
                                    ck3x.setChecked(true);
                                    ck2x.setChecked(false);
                                    ck1x.setChecked(false);
                                }

                            }

                            @Override
                            public void onStartTrackingTouch(SeekBar seekBar) {
                                return;

                            }

                            @Override
                            public void onStopTrackingTouch(SeekBar seekBar) {
                                return;
                            }

                        });

                    }
                    if (pagepointer==1){
                        Toast.makeText(MainActivity.this,"no page on right",Toast.LENGTH_SHORT).show();
                    }
                }
            }
            return super.onFling(e1, e2, velocityX, velocityY);
        }
    }
    @Override
    public  boolean onTouchEvent(MotionEvent event){
        myfinger.onTouchEvent(event);
        return  super.onTouchEvent(event);
    }

    @Override
    protected void onActivityResult  (int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode==gallery_request_code && resultCode==RESULT_OK && data!=null) {
            Uri image_data = data.getData();
            imv_pho = findViewById(R.id.photo);
            imv_pho.setBackgroundResource(0);
            imv_pho.setImageURI(image_data);
            photo = ((BitmapDrawable) imv_pho.getDrawable()).getBitmap();
        }

        if (requestCode==gallery_request_key && resultCode==RESULT_OK && data!=null){
            Uri image_data = data.getData();
            imv_key = findViewById(R.id.mask);
            imv_key.setBackgroundResource(0);
            imv_key.setImageURI(image_data);
            mask = ((BitmapDrawable) imv_key.getDrawable()).getBitmap();
        }
    }


    public void maskx(View v){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent,"get photo"),gallery_request_key);
    }

    public void ph(View v){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent,"get photo"),gallery_request_code);
    }

    public void d1(View v)
    {
        SeekBar sbr = findViewById(R.id.sb);
        CheckBox code0 = findViewById(R.id.ck0);
        CheckBox code1 = findViewById(R.id.ck1);
        CheckBox code2 = findViewById(R.id.ck2);
        if ( code1.isChecked()==true) {
            code2.setChecked(false);
            code0.setChecked(false);
            sbr.setProgress(0);
            return;
        }
    }

    public void dialog(View v){
        LayoutInflater factory = LayoutInflater.from(this);
        final View textEntryView = factory.inflate(R.layout.dialog, null);
        final EditText editTextnumber = (EditText) textEntryView.findViewById(R.id.editTextnumber);
        final EditText editTextkey = (EditText)textEntryView.findViewById(R.id.editTextkey);
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        final String cur_key = settings.getString("my_key","hello");
        AlertDialog.Builder ad1 = new AlertDialog.Builder(this);
        ad1.setTitle("enquiry:");
        ad1.setIcon(android.R.drawable.ic_dialog_info);
        ad1.setView(textEntryView);
        ad1.setPositiveButton("done", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int i) {
                SharedPreferences settings = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = settings.edit();
                String num =editTextnumber.getText().toString();
                String cc_key = editTextkey.getText().toString();
                if (cc_key.contentEquals(cur_key)){
                    int numm= settings.getInt(num,-3);
                    Toast.makeText(MainActivity.this,String.valueOf(numm),Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this,"password is wrong",Toast.LENGTH_SHORT).show();
                }
            }
        });
        ad1.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int i) {

            }
        });
        //register
        final EditText inputServer = new EditText(this);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("register").setIcon(android.R.drawable.ic_dialog_info).setView(inputServer)
                .setNegativeButton("Cancel", null);
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                String my_ley = inputServer.getText().toString();
                SharedPreferences settings = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("my_key",my_ley);
                editor.commit();
            }
        });


        if(cur_key=="hello"){
            builder.show();
        } else {
            ad1.show();
        }
    }

    public void d2(View v)
    {   SeekBar sbr = findViewById(R.id.sb);
        CheckBox code0 = findViewById(R.id.ck0);
        CheckBox code1 = findViewById(R.id.ck1);
        CheckBox code2 = findViewById(R.id.ck2);
        if ( code2.isChecked()==true) {
            code1.setChecked(false);
            code0.setChecked(false);
            sbr.setProgress(0);
            return;
        }
    }

    public void d0(View v)
    {
        SeekBar sbr = findViewById(R.id.sb);
        CheckBox code0 = findViewById(R.id.ck0);
        CheckBox code1 = findViewById(R.id.ck1);
        CheckBox code2 = findViewById(R.id.ck2);
        if ( code0.isChecked()==true) {
            code1.setChecked(false);
            code2.setChecked(false);
            return;
        }
    }

    public int b2i(String bina){
        char[] array = bina.toCharArray();
        int l = array.length;
        double sum = 0;
        for (   int i=0;i<l;i++    )
        {
            int x = Integer.parseInt(String.valueOf(array[i]));
            double v = (double) (l-i-1);
            sum=sum+x*Math.pow(2,v);
        }
        int sum2 = (int)sum;
        return sum2;
    }

    public int[] modify(int r, int g, int b, int val){
        String br = Integer.toBinaryString(r);
        String bg = Integer.toBinaryString(g);
        String bb = Integer.toBinaryString(b);
        String bval = Integer.toBinaryString(val);
        char[] ccbv = bval.toCharArray();
        char[] cbv={'0','0','0','0','0','0'};char[] cbb = bg.toCharArray();
        char[] cbr = br.toCharArray();char[] cbg = bg.toCharArray();
        int ll = 6-ccbv.length;
        for (int i = 0;i<ccbv.length;i++){
            cbv[i+ll]=ccbv[i];
        }

        int xr=0;int xg=0;int xb=0;
        if (cbr.length<=2){
            char[] cb={cbv[0],cbv[1]};
            String rrr = String.valueOf(cb);
            xr = b2i(rrr);
        }

        if (cbr.length>2){
            cbr[cbr.length-2]=cbv[0];
            cbr[cbr.length-1]=cbv[1];
            xr=b2i(String.valueOf(cbr));
        }

        if (cbg.length<=2){
            char[] tt={cbv[2],cbv[3]};
            String ttt = String.valueOf(tt);
            xg = b2i(ttt);
        }

        if (cbg.length>2){
            cbg[cbg.length-2]=cbv[2];
            cbg[cbg.length-1]=cbv[3];
            xg=b2i(String.valueOf(cbg));
        }

        if (cbb.length<=2){
            char[] zz={cbv[4],cbv[5]};
            String zzz = String.valueOf(zz);
            xb = b2i(zzz);
        }
        if (cbb.length>2){
            cbb[cbb.length-2]=cbv[4];
            cbb[cbb.length-1]=cbv[5];
            xb=b2i(String.valueOf(cbb));
        }

        int[] color={xr,xg,xb};
        return color;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void encode(View v) throws IOException {
        SeekBar sek = findViewById(R.id.sb);
        CheckBox ck0 = findViewById(R.id.ck0);
        CheckBox ck1 = findViewById(R.id.ck1);
        CheckBox ck2 = findViewById(R.id.ck2);
        if(ck1.isChecked()==false && ck2.isChecked()==false && ck0.isChecked()==false){
            Toast.makeText(MainActivity.this,"choose one method first",Toast.LENGTH_SHORT).show();
            System.out.println(global_bar);
            return;
        }
        if (ck0.isChecked()){
            ImageView imv0 = findViewById(R.id.photo);
            Bitmap image0 = ((BitmapDrawable) imv0.getDrawable()).getBitmap();
            enc0(image0);
        }

        try {

            if (ck1.isChecked()) {
                ImageView imv = findViewById(R.id.photo);
                Bitmap image = ((BitmapDrawable) imv.getDrawable()).getBitmap();
                enc1(image);
            }
        } catch (Exception e){
            Toast.makeText(MainActivity.this,"wrong image",Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            if (ck2.isChecked()) {
                EditText ed = findViewById(R.id.tex);
                String text = ed.getText().toString();
                int l = text.length();
                String length = String.valueOf(l);
                length = length + "  ";
                text = length + text;
                ImageView imv = findViewById(R.id.photo);
                Bitmap image = ((BitmapDrawable) imv.getDrawable()).getBitmap();
                Bitmap img2 = image.copy(image.getConfig(), true);
                char[] word = text.toCharArray();
                int[] word2 = new int[word.length];
                for (int i = 0; i < word.length; i++) {
                    if (word[i]=='\n'){
                        word[i]='.';
                    }
                    word2[i] = mapcti.get(word[i]);
                }

                int height = image.getHeight();
                int width = image.getWidth();
                int counter = 0;
                int pointer = 0;
                Boolean state = true;
                int tes = 0;
                for (int i = 0; i < width && state; i++) {
                    for (int j = 0; j < height && state; j++) {
                        int col = image.getPixel(i, j);
                        tes = tes + 1;
                        pointer = word2[counter];
                        int[] color = modify(Color.red(col), Color.green(col), Color.blue(col), pointer);
                        img2.setPixel(i, j, Color.rgb(color[0], color[1], color[2]));
                        counter = counter + 1;
                        if (counter == word2.length) {
                            state = false;
                        }
                    }
                }

                File pathx = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                String timeStampx = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
                String fname = "code_" + timeStampx + ".png";
                File imgx = new File(pathx, fname);
                try {
                    FileOutputStream outx = new FileOutputStream(imgx);
                    img2.compress(Bitmap.CompressFormat.PNG, 100, outx);
                    outx.flush();
                    outx.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e){
            Toast.makeText(MainActivity.this,"wrong text",Toast.LENGTH_SHORT).show();
            return;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void decode(View v) throws IOException {
        CheckBox ck1 = findViewById(R.id.ck1);
        CheckBox ck2 = findViewById(R.id.ck2);
        CheckBox ck0 = findViewById(R.id.ck0);
        if(ck1.isChecked()==false && ck2.isChecked()==false && ck0.isChecked()==false){
            Toast.makeText(MainActivity.this,"choose one method first",Toast.LENGTH_SHORT).show();
            return;
        }


        if (ck0.isChecked()){

            ImageView imv0 = findViewById(R.id.photo);
            Bitmap image0 = ((BitmapDrawable) imv0.getDrawable()).getBitmap();
            dec0(image0);
        }

        try {
            if (ck1.isChecked()) {
                ImageView data = findViewById(R.id.photo);
                Bitmap data_im = ((BitmapDrawable) data.getDrawable()).getBitmap();
                Bitmap key_im = mask;
                dec1(key_im,data_im);
            }
        } catch(Exception e) {
            Toast.makeText(MainActivity.this,"wrong image",Toast.LENGTH_SHORT).show();
            return;
        }

        try{
            if(ck2.isChecked()){
            int count;
            ImageView textim = findViewById(R.id.photo);
            Bitmap imt = ((BitmapDrawable) textim.getDrawable()).getBitmap();
            int width = imt.getWidth();
            int height = imt.getHeight();
            int crr =0; int cgg =0; int cbb =0;
            String r1; String g1; String b1;
            String sum ="";
            int key=0;
            String line="";
            String temp ="";
            char c=' ';
            int test=0;
            String linelength="";
            Boolean state = true;
            int numr=0;int numg=0; int numb=0;
            int see=0;
            for(int u=0;u<6;u++){
                int col2 = imt.getPixel(0,u);
                numr=Color.red(col2);numg=Color.green(col2);numb=Color.blue(col2);
                r1=Integer.toBinaryString(numr);g1=Integer.toBinaryString(numg);b1=Integer.toBinaryString(numb);
                int ln1=r1.length(); int ln2 = g1.length(); int ln3 = b1.length();
                r1=r1.substring(Math.max(0,ln1-2)); g1=g1.substring(Math.max(0,ln2-2)); b1=b1.substring(Math.max(0,ln3-2));
                sum=r1+g1+b1;
                key = b2i(sum);
                c = mapitc.get(key);
                if (Character.isDigit(c)){
                    temp=String.valueOf(c);
                    linelength=linelength.concat(temp);
                    see=u;
                    continue;
                }
                break;
            }
            int totlen = Integer.valueOf(linelength);
            totlen=totlen+see+2;
            for (int i = 0; i < width && state; i++) {
                for (int j = 0; j < height && state; j++) {
                    test=test+1;
                    int col = imt.getPixel(i, j);
                    crr=Color.red(col); cgg=Color.green(col);cbb=Color.blue(col);
                    r1=Integer.toBinaryString(crr);g1=Integer.toBinaryString(cgg);b1=Integer.toBinaryString(cbb);
                    int l1=r1.length(); int l2=g1.length(); int l3=b1.length();
                    r1=r1.substring(Math.max(0,l1-2)); g1=g1.substring(Math.max(0,l2-2)); b1=b1.substring(Math.max(0,l3-2));
                    sum=r1+g1+b1;
                    key = b2i(sum);
                    c = mapitc.get(key);
                    temp=String.valueOf(c);
                    line=line.concat(temp);
                    if (test>totlen){
                        state=false;
                    }
                }
            }
            EditText ed2 = findViewById(R.id.tex);
            line=line.substring(see+2);
            ed2.setText(line);

        }
        }catch (Exception e){
            Toast.makeText(MainActivity.this,"wrong image",Toast.LENGTH_SHORT).show();
            return;
        }

    }


    public void enc1(final Bitmap bitmap){

      new Thread(new Runnable() {
          @RequiresApi(api = Build.VERSION_CODES.N)
          @Override
          public void run() {


              Random myrandom = new Random();

              Bitmap mask = bitmap.copy(bitmap.getConfig(), true);
              Bitmap data = bitmap.copy(bitmap.getConfig(), true);
              int height = bitmap.getHeight();
              int width = bitmap.getWidth();
              for (int i = 0; i < width; i++) {
                  for (int j = 0; j < height; j++) {
                      int col = bitmap.getPixel(i, j);
                      int val = myrandom.nextInt(255);
                      mask.setPixel(i, j, Color.rgb(val, val, val));
                      data.setPixel(i, j, Color.rgb(Color.red(col) ^ val, Color.green(col) ^ val, Color.blue(col) ^ val));
                  }
              }

              File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
              String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
              String fname = "mask_" + timeStamp + ".png";
              String fname2 = "data_" + timeStamp + ".png";
              File imgf = new File(path, fname);
              File imgf2 = new File(path, fname2);
              try {
                  FileOutputStream out = new FileOutputStream(imgf);
                  mask.compress(Bitmap.CompressFormat.PNG, 100, out);
                  out.flush();
                  out.close();
              } catch (Exception e) {
                  e.printStackTrace();
              }

              try {
                  FileOutputStream out2 = new FileOutputStream(imgf2);
                  data.compress(Bitmap.CompressFormat.PNG, 100, out2);
                  out2.flush();
                  out2.close();
              } catch (Exception e) {
                  e.printStackTrace();
              }


          }
      }).start();
    }

    public void enc0(final Bitmap bitmap){

        new Thread(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void run() {

                int co = global_bar;
                double x0 = Double.valueOf(co);
                x0=x0/100;

                Bitmap image0 = bitmap;
                Bitmap mask0 = image0.copy(image0.getConfig(), true);
                int height0 = image0.getHeight();
                int width0 = image0.getWidth();
                for (int i = 0; i < width0; i++) {
                    for (int j = 0; j < height0; j++) {
                        int col0 = image0.getPixel(i, j);
                        double cur = coffecient*(x0)*(1-x0);
                        double cur2 = cur*256;
                        int near = (int)cur2;
                        x0 = cur;
                        int r = Color.red(col0);int g = Color.green(col0);int b = Color.blue(col0);
                        mask0.setPixel(i, j, Color.rgb(r^near, g^near, b^near));
                    }
                }

                SharedPreferences settings = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = settings.edit();
                int c_count = settings.getInt("0",-7);
                String identify = String.valueOf(c_count+1);

                File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                //String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
                String fname0 = "chaos_"+"_" + identify + ".png";
                editor.putInt(identify,global_bar);
                editor.putInt("0",c_count+1);
                editor.commit();
                File imgf0 = new File(path, fname0);
                try {
                    FileOutputStream out0 = new FileOutputStream(imgf0);
                    mask0.compress(Bitmap.CompressFormat.PNG, 100, out0);
                    out0.flush();
                    out0.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
        }).start();
    }



    public void dec0(final Bitmap bitmap){

        new Thread(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void run() {
                int co = global_bar;
                double x0 = Double.valueOf(co);
                x0=x0/100;
                final ImageView imv0 = findViewById(R.id.photo);
                Bitmap image0 = ((BitmapDrawable) imv0.getDrawable()).getBitmap();
                final Bitmap mask0 = image0.copy(image0.getConfig(), true);
                int height0 = image0.getHeight();
                int width0 = image0.getWidth();
                for (int i = 0; i < width0; i++) {
                    for (int j = 0; j < height0; j++) {
                        int col0 = image0.getPixel(i, j);
                        double cur = coffecient*(x0)*(1-x0);
                        double cur2 = cur*256;
                        int near = (int)cur2;
                        x0 = cur;
                        int r = Color.red(col0);int g = Color.green(col0);int b = Color.blue(col0);
                        mask0.setPixel(i, j, Color.rgb(r^near, g^near, b^near));
                    }
                }
                imv0.post(new Runnable() {
                    @Override
                    public void run() {
                        imv0.setImageBitmap(null);
                        imv0.setImageBitmap(mask0);

                    }
                });




            }
        }).start();
    }


    public void dec1(final Bitmap key_im, final Bitmap data_im){

        new Thread(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void run() {

                int height = key_im.getHeight();
                int width = key_im.getWidth();
                final Bitmap img = key_im.copy(key_im.getConfig(), true);

                for (int i = 0; i < width; i++) {
                    for (int j = 0; j < height; j++) {
                        int col_key = key_im.getPixel(i, j);
                        int col_data = data_im.getPixel(i, j);
                        img.setPixel(i, j, Color.rgb(Color.red(col_key) ^ Color.red(col_data), Color.green(col_key) ^ Color.green(col_data), Color.blue(col_key) ^ Color.blue(col_data)));
                    }
                }
                final ImageView data = findViewById(R.id.photo);
                data.post(new Runnable() {
                    @Override
                    public void run() {
                        data.setImageBitmap(null);
                        data.setImageBitmap(img);

                    }
                });

            }
        }).start();
    }




}
